package com.example.divya.app_lock;

import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.divya.app_lock.BackService.SCreenServiceNew;
import com.example.divya.app_lock.BackService.ScreenOnOffService;

import static android.R.id.edit;
import static java.sql.Types.NULL;

public class AppLock extends AppCompatActivity {

    private Button setbtn;
    private Button changebtn;
    private Button forgetbtn;

    SharedPreferences SPREF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_lock);
        init();
        Typeface mytypeface = Typeface.createFromAsset(getAssets(),"AlphaFridgeMagnets.ttf");
        TextView mytv = (TextView)findViewById(R.id.tv1);
        mytv.setTypeface(mytypeface);
         SPREF = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
        onClickButtonListener();
        onClickButtonListener1();
        onClickButtonListener2();
       checkPinStatus();

        Intent i = new Intent(this, ScreenOnOffService.class);
        i.putExtra("screen_state", true);
        startService(i);

    }




    private void init() {
        setbtn = (Button) findViewById(R.id.btn1);
        changebtn = (Button) findViewById(R.id.btn2);
        forgetbtn = (Button) findViewById(R.id.forgetpin);
    }

   private void checkPinStatus() {
        System.out.println("SPREF value=" + SPREF.getString("PIN", null));
       /* if (SPREF.getString("PIN", null) == null) {
            ///
        } else {*/
           if (SPREF.getString("PIN", null)==null || SPREF.getString("PIN", null)==" ") {
                changebtn.setVisibility(View.GONE);
                setbtn.setVisibility(View.VISIBLE);
            } else {
                changebtn.setVisibility(View.VISIBLE);
                setbtn.setVisibility(View.GONE);
            }
        //}
    }

    public void onClickButtonListener() {

        setbtn.setOnClickListener(
                new View.OnClickListener() {
            @Override
                    public void onClick(View V) {
                Intent i = new Intent(AppLock.this, SetPIN.class);
                startActivity(i);
            }


        }
        );
    }

    public void onClickButtonListener2() {

        forgetbtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View V) {
                        Intent i = new Intent(AppLock.this, Username.class);
                        startActivity(i);
                    }


                }
        );
    }

    public void onClickButtonListener1() {

        changebtn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View V) {
                        Intent i = new Intent(AppLock.this, ChangePIN.class);
                        startActivity(i);
                    }


                }
        );
    }
}
