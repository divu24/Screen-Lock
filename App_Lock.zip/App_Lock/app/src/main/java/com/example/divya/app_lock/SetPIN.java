package com.example.divya.app_lock;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.R.attr.start;

public class SetPIN extends AppCompatActivity {

    EditText editText1, editText2, editText3;
    Button setsavebtn1;

   public static final String MyPREFERENCES = "MyPrefs";
    public static final String PIN = "PIN";
    public static final String Reenter = "Re-PIN";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_pin);

        editText1 = (EditText) findViewById(R.id.et1);
        editText2 = (EditText) findViewById(R.id.et2);
        editText3 = (EditText) findViewById(R.id.email);
        setsavebtn1 = (Button) findViewById(R.id.btn3);



        setsavebtn1.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View v) {
                String password1 = editText1.getText().toString();
                String password2 = editText2.getText().toString();
                String email = editText3.getText().toString();

                editText1.getText().toString();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if ((editText1.getText().toString().equalsIgnoreCase("") ) ||
                        (editText2.getText().toString().equalsIgnoreCase("") ) ||
                        (editText3.getText().toString().equalsIgnoreCase("")))

                {
                    Toast.makeText(getApplicationContext(), "You did not enter either Password or E-mail", Toast.LENGTH_SHORT).show();
                }


                else if ((password1.length() < 4) || ((password2.length() < 4)) )
                {  Toast.makeText(getApplicationContext(), "Password can not be less than 4", Toast.LENGTH_SHORT).show();
                }

                else if (!email.matches(emailPattern))  {
                    Toast.makeText(getApplicationContext(),"Enter valid email address",Toast.LENGTH_SHORT).show();
                }

                else

                {

                    if(password1.equals(password2)) {
                        Toast.makeText(getApplicationContext(), "Password Set Successfully", Toast.LENGTH_SHORT).show();

                        SharedPreferences sharedpreferences1 = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedpreferences1.edit();
                        editor.putString("PIN", password1);
                        editor.putString("EmailId", email);
                        editor.commit();

                        Intent i= new Intent(SetPIN.this, AppLock.class);
                        startActivity(i);
                    }

                    else
                    {
                        Toast.makeText(getApplicationContext(), "Passwords do not match!", Toast.LENGTH_LONG).show();
                    }
                }


            }

        });

    }


}