package com.example.divya.app_lock;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import static com.example.divya.app_lock.SetPIN.PIN;

public class Username extends AppCompatActivity {

    EditText emailuser;
    Button emilbtn;
    TextView usertext;

    private String getPinValuefromPref1, getPinValuefromPref2 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.username);

        emailuser = (EditText) findViewById(R.id.emailid);
        emilbtn = (Button) findViewById(R.id.emailbtn);
        usertext = (TextView) findViewById(R.id.textView3);

        emilbtn.setOnClickListener( new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                String username = emailuser.getText().toString();

                SharedPreferences sharedpreferences1 = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences1.edit();

                getPinValuefromPref1= sharedpreferences1.getString("EmailId",null);
                getPinValuefromPref2 = sharedpreferences1.getString("PIN", null);
               //  System.out.println("email-->" +getPinValuefromPref1);

                if ((username.equalsIgnoreCase(""))) {

                    Toast.makeText(getApplicationContext(), "You did not enter E-mail", Toast.LENGTH_SHORT).show();
                }

                else if(username.equals(getPinValuefromPref1))
                {
                   usertext.setText("Your PIN : "+getPinValuefromPref2);


                    }
                else
                {
                    Toast.makeText(getApplicationContext(), "Enter the correct E-mail ID", Toast.LENGTH_SHORT).show();
                }

            }


        });
    }
}
