package com.example.divya.app_lock.BackService;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;

import com.example.divya.app_lock.AppLock;
import com.example.divya.app_lock.Home;
import com.example.divya.app_lock.R;
import com.example.divya.app_lock.ScreenLockBroadCastReciever;

/**
 * Created by Divya on 6/15/2017.
 */

public class ScreenOnOffService  extends Service{

    Context con;
    private static int NOTIFY_ID=1337;
    private static int FOREGROUND_ID=1338;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        con = this;


    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);


    }





    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
      //  return super.onStartCommand(intent, flags, startId)

        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        BroadcastReceiver mReceiver = new ScreenLockBroadCastReciever();
        registerReceiver(mReceiver, filter);

         String STARTFOREGROUND_ACTION = "com.marothiatechs.foregroundservice.action.startforeground";
         String STOPFOREGROUND_ACTION = "com.marothiatechs.foregroundservice.action.stopforeground";

       // Intent notificationIntent = new Intent(this, AppLock.class);
        Intent notificationIntent = new Intent(this, AppLock.class);
      //  notificationIntent.setAction(Constants.ACTION.MAIN_ACTION);
       // notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pendingIntent=PendingIntent.getActivity(this, 0,
                notificationIntent, 0);

        Notification notification=new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentText("testtt")

                .setContentIntent(pendingIntent).build();

        startForeground(1, notification);






        //Toast.makeText(getApplicationContext(),"TEs service runnning",Toast.LENGTH_SHORT).show();
       /* if (intent.getAction().equals(STARTFOREGROUND_ACTION)) {
           // Log.i(LOG_TAG, "Received Start Foreground Intent ");
            runAsForeground();
            Toast.makeText(this, "Service Started!", Toast.LENGTH_SHORT).show();

        }
*/
        boolean screenOn = intent.getBooleanExtra("screen_state", false);
        if (!screenOn) {
            System.out.println("Screen is off");

           /* Intent intent_applock =  new Intent(getApplicationContext(), Home.class);
            intent_applock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent_applock);*/
        } else {
            System.out.println("Screen is on");
        }
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}
