package com.example.divya.app_lock;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static com.example.divya.app_lock.R.id.pinenter;
import static com.example.divya.app_lock.R.id.textView;

public class Home extends AppCompatActivity {

    String oldpassword;
    private EditText passwordedit;
   // private TextView enterpin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        passwordedit = (EditText) findViewById(R.id.editpin);
        // enterpin = (TextView) findViewById(R.id.pinenter);
        passwordedit.addTextChangedListener(textWatcher);

        SharedPreferences sharedPreferences = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        oldpassword = (sharedPreferences.getString("PIN", " "));
        System.out.println(" PIN" + oldpassword);

    }
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                String pin = passwordedit.getText().toString();
                if (oldpassword.equals(pin)) {
                    System.out.println("Test true == ");
                    Home.this.finish();
                } else {
                    System.out.println("Test not equal ");
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };


     //   enterpin = (TextView) findViewById(R.id.pinenter);
       // enterpin.setTypeface(mytypeface);



    }




