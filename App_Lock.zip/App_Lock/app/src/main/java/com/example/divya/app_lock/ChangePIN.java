package com.example.divya.app_lock;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ChangePIN extends AppCompatActivity {
    EditText et3, et4,et5;
    Button btn4;


    public static final String MyPREFERENCES1 = "MyPrefs1";
    public static final String PIN1 = "OLD PIN";
    public static final String newenter = "New PIN";
    public static final String reenternew = "Re-Enter PIN";
    private String  getPinValuefromPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_pin);




        et3=(EditText)findViewById(R.id.et3);
        et4=(EditText)findViewById(R.id.et4);
        et5=(EditText)findViewById(R.id.et5);
        btn4=(Button) findViewById(R.id.btn4);


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String password7 = et3.getText().toString();
                String password8 = et4.getText().toString();
                String password9 = et5.getText().toString();

                SharedPreferences sharedpreferences1 = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences1.edit();

                getPinValuefromPref =  sharedpreferences1.getString("PIN"," ");

                if(password7.equalsIgnoreCase("")|password8.equalsIgnoreCase("")|password9.equalsIgnoreCase(""))
                {
                    Toast.makeText(ChangePIN.this, "You did not enter the Password", Toast.LENGTH_SHORT).show();

                }


                else if (!password7.equals(getPinValuefromPref)) {
                    Toast.makeText(ChangePIN.this, " Enter the correct Password", Toast.LENGTH_SHORT).show();

                }

                else if ((password8.length() < 4) || ((password9.length() < 4)) )
                {  Toast.makeText(getApplicationContext(), "Password can not be less than 4", Toast.LENGTH_SHORT).show();
                }

                else {
                    if (!password8.equals(password9))
                    {
                        Toast.makeText(ChangePIN.this, "New Passwords do not match!! Re-enter", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(ChangePIN.this, "Password changed successfully!!", Toast.LENGTH_SHORT).show();

                        SharedPreferences sharedPreferences = getSharedPreferences("MyPREFERENCES1", MODE_PRIVATE);
                        SharedPreferences.Editor edit = sharedpreferences1.edit();
                        editor.putString("PIN", password8);
                        editor.commit();



                    finish();

                    }
                }


            }
        });
    }

}







