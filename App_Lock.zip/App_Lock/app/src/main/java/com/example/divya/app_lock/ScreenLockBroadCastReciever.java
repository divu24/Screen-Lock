package com.example.divya.app_lock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.divya.app_lock.BackService.ScreenOnOffService;

/**
 * Created by Divya on 6/14/2017.
 */

public class ScreenLockBroadCastReciever extends BroadcastReceiver {
    boolean screenOff;
    @Override
    public void onReceive(Context context, Intent intent) {

        System.out.println("onReceive ");
       /* if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
            screenOff = true;
            System.out.println("SCREEN TURNED OFF on BroadcastReceiver");
        } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
            screenOff = false;
            System.out.println("SCREEN TURNED ON on BroadcastReceiver");
        }*/
     /*   Intent i = new Intent(context, ScreenOnOffService.class);
        i.putExtra("screen_state", screenOff);
        context.startService(i);*/
        Intent intent_applock =  new Intent(context, Home.class);
        intent_applock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent_applock);
    }

}
